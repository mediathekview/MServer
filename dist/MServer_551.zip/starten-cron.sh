#!/bin/sh
#

/home/emil/bin/mediathek/MvServer.sh >> /home/emil/bin/mediathek/log/cron__`date "+%Y.%m.%d"`.log &

exit 0





